#!/usr/bin/env python

import pyvona as iv
import requests

r = requests.get('http://robotics.usc.edu')
#print r.headers

v = iv.create_voice("GDNAJYDWFVWE7HEH4ZLA","2JyYsTIU4apa3xFVj2rAJQxQmaixhwZtv2V+/pII", "Justin")

v.fetch_voice("hello world!", "hi.ogg")
v.fetch_marks("hello world!", "hi.txt")
